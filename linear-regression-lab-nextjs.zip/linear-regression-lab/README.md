# Linear Regression Lab

An interactive, client-side educational laboratory inspired by the architecture of SequenceLab AI. It is an original teaching tool for Simple Linear Regression.

## Features
- Dataset scenarios: Study Hours → Exam Marks, Advertising → Sales, Outlier Investigation
- Interactive regression chart
- Best-fit slope/intercept, MSE, SSE and R² calculations
- Prediction challenge
- Observation table with residuals and squared errors
- Gradient Descent Playground
- Responsive Next.js + TypeScript + Tailwind UI

## Run

Requires Node.js 20+.

```bash
npm install
npm run dev
```

Open http://localhost:3000.

## Build

```bash
npm run typecheck
npm run build
npm start
```

This project is an original implementation; it does not copy the source code of SequenceLab AI.
