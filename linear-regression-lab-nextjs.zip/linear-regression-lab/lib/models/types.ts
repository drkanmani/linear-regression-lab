export type Point = { id:number; x:number; y:number }
export type RegressionResult = { slope:number; intercept:number; mse:number; sse:number; r2:number }
export type Dataset = { id:string; name:string; xLabel:string; yLabel:string; points:Point[]; description:string }
