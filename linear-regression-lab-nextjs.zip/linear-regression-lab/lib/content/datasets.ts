import { Dataset } from '@/lib/models/types'
export const datasets:Dataset[]=[
 {id:'study',name:'Study Hours → Exam Marks',xLabel:'Study hours',yLabel:'Exam mark',description:'Explore how study time can be used to predict exam performance.',points:[{id:1,x:1,y:35},{id:2,x:2,y:42},{id:3,x:3,y:50},{id:4,x:4,y:58},{id:5,x:5,y:65},{id:6,x:6,y:72}]},
 {id:'sales',name:'Advertising → Sales',xLabel:'Advertising spend',yLabel:'Sales',description:'A simple business analytics example showing a positive relationship.',points:[{id:1,x:1,y:12},{id:2,x:2,y:17},{id:3,x:3,y:19},{id:4,x:4,y:25},{id:5,x:5,y:29},{id:6,x:6,y:33}]},
 {id:'outlier',name:'Outlier Investigation',xLabel:'Feature X',yLabel:'Target Y',description:'See how one unusual observation can pull the regression line.',points:[{id:1,x:1,y:20},{id:2,x:2,y:23},{id:3,x:3,y:28},{id:4,x:4,y:31},{id:5,x:5,y:35},{id:6,x:6,y:78}]}
]
