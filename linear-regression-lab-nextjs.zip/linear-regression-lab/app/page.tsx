import LabApp from '@/features/linear-regression/components/LabApp'
export default function Page(){return <LabApp/>}
