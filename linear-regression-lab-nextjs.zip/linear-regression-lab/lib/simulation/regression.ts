import { Point, RegressionResult } from '@/lib/models/types'
export function fitRegression(points:Point[]):RegressionResult{
 const n=points.length; if(n<2) return {slope:0,intercept:0,mse:0,sse:0,r2:0}
 const sx=points.reduce((s,p)=>s+p.x,0), sy=points.reduce((s,p)=>s+p.y,0)
 const sxy=points.reduce((s,p)=>s+p.x*p.y,0), sx2=points.reduce((s,p)=>s+p.x*p.x,0)
 const den=n*sx2-sx*sx; const slope=den===0?0:(n*sxy-sx*sy)/den; const intercept=(sy-slope*sx)/n
 const mean=sy/n; let sse=0, sst=0
 for(const p of points){const e=p.y-(intercept+slope*p.x);sse+=e*e;sst+=(p.y-mean)**2}
 return {slope,intercept,mse:sse/n,sse,r2:sst===0?1:1-sse/sst}
}
export function predict(x:number,r:RegressionResult){return r.intercept+r.slope*x}
export function residuals(points:Point[],r:RegressionResult){return points.map(p=>({...p,predicted:predict(p.x,r),residual:p.y-predict(p.x,r)}))}
export function gradientStep(points:Point[],m:number,b:number,lr:number){
 const n=points.length; let dm=0,db=0
 for(const p of points){const e=(m*p.x+b)-p.y; dm+=e*p.x; db+=e}
 return {m:m-lr*2*dm/n,b:b-lr*2*db/n}
}
