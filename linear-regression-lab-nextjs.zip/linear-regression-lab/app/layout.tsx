import './globals.css'
export const metadata={title:'Linear Regression Lab',description:'Interactive educational laboratory for learning linear regression.'}
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
