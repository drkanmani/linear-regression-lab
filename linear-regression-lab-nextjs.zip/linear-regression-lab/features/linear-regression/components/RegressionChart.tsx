'use client'
import { useMemo } from 'react'
import { LineChart,Line,XAxis,YAxis,CartesianGrid,Tooltip,Scatter,ScatterChart,ReferenceLine,ResponsiveContainer,Legend } from 'recharts'
import { Point, RegressionResult } from '@/lib/models/types'
import { predict } from '@/lib/simulation/regression'
export default function RegressionChart({points,result,xLabel,yLabel}:{points:Point[];result:RegressionResult;xLabel:string;yLabel:string}){
 const data=useMemo(()=>{const xs=points.map(p=>p.x);const min=Math.min(...xs),max=Math.max(...xs);const pad=(max-min||1)*.15;const a=min-pad,b=max+pad;return [{x:a,fit:predict(a,result)},{x:b,fit:predict(b,result)}]},[points,result])
 const rows=points.map(p=>({x:p.x,y:p.y,fit:predict(p.x,result)}))
 return <div className="h-[420px] w-full"><ResponsiveContainer><LineChart data={rows} margin={{top:20,right:25,left:5,bottom:20}}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="x" type="number" label={{value:xLabel,position:'insideBottom',offset:-10}}/><YAxis label={{value:yLabel,angle:-90,position:'insideLeft'}}/><Tooltip/><Legend/><Line data={data} dataKey="fit" name="Best-fit line" stroke="#2563eb" strokeWidth={3} dot={false} isAnimationActive={false}/><Scatter data={rows} dataKey="y" name="Observed data" fill="#0f766e"/></LineChart></ResponsiveContainer></div>
}
